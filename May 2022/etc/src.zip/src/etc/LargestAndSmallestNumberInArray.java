package etc;

public class LargestAndSmallestNumberInArray {

    public static int findSmallestNumber(int[] array) {
        int result = Integer.MAX_VALUE;

        for (int num : array) {
            if (num < result) {
                result = num;
            }
        }
        return result;
    }

    public static int findLargestNumber(int[] array) {
        int result = Integer.MIN_VALUE;

        for (int num : array) {
            if (num > result) {
                result = num;
            }
        }
        return result;
    }


    public static void main(String[] args) {
        int[] array = {1, 4, 7, -15, 1, -230, 230};
        System.out.println("Smallest element is: " + findSmallestNumber(array));
        System.out.println("Largest element is: " + findLargestNumber(array));
    }
}
