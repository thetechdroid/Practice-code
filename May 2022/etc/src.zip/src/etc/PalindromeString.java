package etc;

public class PalindromeString {

    public static boolean isPalindrome(String str) {

        // brute force way is to reverse the string and then compare both strings =


        // another way is to convert into char array and compare
        char[] array = str.toCharArray();
        int length = array.length;

        int i = 0;
        int j = length - 1;

        while (i < j) {
            if (Character.toLowerCase(array[i]) != Character.toLowerCase(array[j])) { // if case sensitivity is ignored
                return false;
            }
            i++;
            j--;
        }
        return true;
    }


    public static void main(String[] args) {

        String first = "Testing Palindrome";
        String second = "KaYak";
        String third = "kayak";

        System.out.println("First is palindrome : " + isPalindrome(first));
        System.out.println("Second is palindrome : " + isPalindrome(second));
        System.out.println("Third is palindrome : " + isPalindrome(third));


    }


}
