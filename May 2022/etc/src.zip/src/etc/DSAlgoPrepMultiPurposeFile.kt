fun main() {


    // palindrome number

    val number1 = 34567
    val number2 = 34543
    val number3 = 345543

    fun checkIfPalindrome(number : Int): Boolean {
        var result = 0
        var num = number
        while (num > 0){
            val lastDigitOfNumber = num % 10
            result = result * 10 + lastDigitOfNumber
            num /= 10
        }
        println("Palindrome $number ->  ${result == number} ")
        return result == number
    }


    //checkIfPalindrome(number1)
    //println("===========")
    //checkIfPalindrome(number2)
    //println("===========")
    //checkIfPalindrome(number3)
    //println("===========")

    // palindrome string
    fun checkIfPalindromeString(value: String): Boolean {
        // method 1
   /*     val reverseStr = StringBuilder(value)
        reverseStr.reverse()
        return reverseStr.toString() == value*/

        // method2
        // For normal array
        var array = value.toCharArray()
        var start = 0
        var end = array.size - 1

        // For array with alphanumerical shit
        var modifiedValue = value
        val regex = Regex("[^a-zA-Z0-9]")
        modifiedValue = modifiedValue.replace(regex, "")

        println(modifiedValue)

        array = modifiedValue.toCharArray()

        println(array)
        end = array.size - 1

        while (start < end) {
            if (array[start].lowercase() == array[end].lowercase()) {
                start++
                end--
                continue
            } else {
                return false
            }
        }
        return true
    }


    println(checkIfPalindromeString("Hello, I am here!!"))
    println("===========")
    println(checkIfPalindromeString("Hello,&*&^olleh"))
    println("===========")


}