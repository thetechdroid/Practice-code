package etc;

public class Fibonacci {


    public static void main(String[] args) {

        // 1 1 2 3 5 8 13 21 34 etc
        int[] array = new int[10];

        array[0] = 1;
        array[1] = 1;

        for (int i = 2; i < array.length; i++) { // O(n)
            array[i] = array[i - 2] + array[i - 1];
        }

        print(array);
    }


    public static void print(int[] nums) {
        for (int n : nums) {
            System.out.print(n + " ");
        }
        System.out.println("");
    }


}
