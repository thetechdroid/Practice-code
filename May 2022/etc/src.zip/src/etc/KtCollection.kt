fun main() {


    val list = listOf("Neymar" to 8, "Messi" to 10, "Suarez" to 8, "Rooney" to 7)

    val (players, skills) = list.unzip()

    //println(players)
    //println(skills)

    val square: (Int) -> Int = { number -> number * number }

    val sqTest = square(12)
    println(sqTest)

    firstFunction()
}


fun firstFunction(){
    var test = "random shit"
    println("Inside first function : $test")

    fun secondFunction() {
        test = "no random shit!!"
        println("Inside second function : $test")
    }

    secondFunction()

//    fun thirdFunction(lambTest: (Int) -> Int): (Int) -> Int {
//        lambTest.invoke(12)
//    }



//val testLambda : (Int) -> Int = thirdFunction { value -> value * value }


}

