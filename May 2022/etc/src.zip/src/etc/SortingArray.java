package etc;

import java.util.Arrays;

public class SortingArray {

    public static int[] sortedArray(int[] array) {

        int[] result = new int[7];

        // using Collections, it orders everything in place, so simply return the array
        Arrays.sort(array);

        // Bubble sort, basic way
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array.length; j++) {
                if (array[i] < array[j]) {
                    result[i] = array[i];
                } else {
                    result[i] = array[j];
                }
            }
        }


        // Bubble sort, concise way
        for (int i = 0; i < array.length; i++) {
            for (int k : array) {
                result[i] = Math.min(array[i], k);
            }
        }

        return result;


    }


    private static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(" " + num + " ");
        }
    }

    public static void main(String[] args) {
        int[] array = {1, 4, 7, -15, 16, -23, 20};

        System.out.println("\n Before sorting ===== ");
        printArray(array);

        System.out.println("\n\n After sorting =====\n ");
        printArray(sortedArray(array));

    }
}
