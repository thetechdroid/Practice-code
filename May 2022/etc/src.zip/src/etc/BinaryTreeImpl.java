package etc;

public class BinaryTreeImpl {

    class TreeNode {
        TreeNode left;
        TreeNode right;
        int data;

        public TreeNode(int d) {
            data = d;
            left = null;
            right = null;
        }
    }


    public void inOrderTraversal(TreeNode root){ // O(n)
        if (root != null) {
            inOrderTraversal(root.left);
            System.out.println(root.data);
            inOrderTraversal(root.right);
        }
    }



}
