package etc;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FindDuplicateInArray {

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 3, 4, 4, 5, 8, 9, 5};

        List<Integer> result = new ArrayList<>();
        List<Integer> uniqueNumbers = new ArrayList<>();

        // find all duplicates
        Set<Integer> set = new HashSet<>();
        for (int j : array) {
            if (set.add(j)) {// the number is unique
                uniqueNumbers.add(j);
            } else {// the number is duplicated
                result.add(j);
                if(uniqueNumbers.contains(j)) {
                    uniqueNumbers.remove((Integer) j);
                }
            }
        }

        print(result);
        printSpaces();
        print(uniqueNumbers);

    }


    private static void print(List<Integer> list) {
        for (Integer integer : list) {
            System.out.println(integer);
        }
    }

    private static void print(int number) {
        System.out.println(number);
    }

    private static void printSpaces() {
        System.out.println("================================================");
    }


}
