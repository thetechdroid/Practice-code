package etc;

public class StringEditDistance {


    public static void main(String[] args) {

        String a = "Hello";
        String b = "";

        int distance = findEditDistance(a, b);
        print(distance);

    }

    private static int findEditDistance(String a, String b) {
        int count = 0;
        if (a.isEmpty()) return b.length();
        if (b.isEmpty()) return a.length();

        if (a.length() == b.length()) {
            for (int i = 0; i < a.length(); i++) {
                if (a.charAt(i) != b.charAt(i)) {
                    count++;
                }
            }
            return count;
        } else {
            int diff = a.length() - b.length();
            count = Math.abs(diff);

//            while(){
//
//            }

        }
return -1;

    }


    private static void print(int distance) {
        System.out.println("edit distance is: " + distance);
    }


}
