package etc;

public class Matrix {

    public static void main(String[] args) {
        int[][] matrix = new int[3][4]; // row 3, column 4

        int row_length = matrix.length;
        int col_length = matrix[0].length;
        print(col_length);
        print(row_length);


    }



    private static void print(int[] array) {
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println("");
    }

    private static void print(int value) {
        System.out.println(value + " ");
    }

}
