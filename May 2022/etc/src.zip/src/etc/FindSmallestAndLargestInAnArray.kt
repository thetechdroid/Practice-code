fun main() {

    val array = intArrayOf(-12, 14, 356, 6, 8, 9)

    var min = Int.MAX_VALUE
    var max = Int.MIN_VALUE

    var test = 0

    array.forEach { number ->
        if (number < min) {
            min = number
        }

        if (number > max) {
            max = number
        }
    }
    println(min)
    println(max)
}