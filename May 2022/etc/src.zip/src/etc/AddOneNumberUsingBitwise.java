package etc;

public class AddOneNumberUsingBitwise {

    private static int addOneUsingBitwise(int num) {
        int m = 1;

        while((num & m) >= 1){
            num = num ^ m;
            m = m << 1;
        }

        num = num ^ m;
        return num;
    }


    public static void main(String[] args) {
        int num = 25;

        int result = addOneUsingBitwise(num);
        print(result);

    }

    private static void print(int item) {
        System.out.println("Number is: " + item);
    }

}

