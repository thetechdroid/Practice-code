package etc;

public class AddBinaryNumbers {

    private static String addBinary(String num1, String num2) {

        int number1 = Integer.parseInt(num1, 2);
        int number2 = Integer.parseInt(num2, 2);

        int number = number1 + number2;
        return Integer.toBinaryString(number);
    }

    /**
     * Study this solution
     * */
    public static String binaryAddition(String s1, String s2) {
        if (s1 == null || s2 == null) return "";
        int first = s1.length() - 1;
        int second = s2.length() - 1;
        StringBuilder sb = new StringBuilder();
        int carry = 0;
        while (first >= 0 || second >= 0) {
            int sum = carry;
            if (first >= 0) {
                sum += s1.charAt(first) - '0';
                first--;
            }
            if (second >= 0) {
                sum += s2.charAt(second) - '0';
                second--;
            }
            carry = sum >> 1;
            sum = sum & 1;
            sb.append(sum == 0 ? '0' : '1');
        }
        if (carry > 0)
            sb.append('1');

        sb.reverse();
        return String.valueOf(sb);
    }

    public static void main(String[] args) {

        String num1 = "10101";
        String num2 = "0011010";

        String result = addBinary(num1, num2);
        String newResult = binaryAddition(num1, num2);
        print(result);
        print(newResult);
    }

    private static void print(String item) {
        int num = Integer.parseInt(item, 2);
        System.out.println("Number is: " + num + "\nBinary is: " + item);
    }

}
