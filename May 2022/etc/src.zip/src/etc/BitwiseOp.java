package etc;

public class BitwiseOp {

    private static int addIntUsingBitwise(int num1, int num2) {
        int result = num1 & 1;
        print(result);
        return result;
    }


    public static void main(String[] args) {

        int num1 = 10;
        int num2 = 7;

        int result = addIntUsingBitwise(num1, num2);
        //print(result);

    }

    private static void print(int item) {
        System.out.println("Number is: " + item);
    }

}
