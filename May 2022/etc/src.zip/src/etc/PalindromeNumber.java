package etc;

public class PalindromeNumber {

    public static boolean isPalindrome(int num) {
        int originalNum = num;
        int result = 0;
        while (num > 0) {
            int temp = num % 10;
            result = result * 10 + temp;
            num = num / 10;
        }
        return (result == originalNum);
    }


    public static void main(String[] args) {

        int first = 72427;
        int second = 789456;


        StringBuilder b = new StringBuilder();
        System.gc();
        Runtime.getRuntime().gc();


        if (isPalindrome(first)) {
            System.out.println("First number is palindrome");
        } else {
            System.out.println("First number is not palindrome");
        }


        if (isPalindrome(second)) {
            System.out.println("Second number is palindrome");
        } else {
            System.out.println("Second number is not palindrome");
        }


    }


}


/*
*
*
* */