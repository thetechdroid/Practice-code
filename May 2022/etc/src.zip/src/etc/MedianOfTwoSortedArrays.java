package etc;

public class MedianOfTwoSortedArrays {

    private static int findMedian(int[] arr1, int[] arr2) {

        if ((arr1 == null && arr2 == null) || (arr1.length == 0 && arr2.length == 0)) {
            return -1;
        }

        int middle1 = (arr1.length - 1) / 2;
        int middle2 = (arr2.length - 1) / 2;


        if (arr2.length == 0) {
            return arr1[middle1];
        } else if (arr1.length == 0) {
            return arr2[middle2];
        }
        return (arr1[middle1] + arr2[middle2])/2;
    }


    public static void main(String[] args) {

        int[] array1 = {1, 2, 3, 4, 5};
        int[] array2 = {6, 8, 10, 12, 16, 18, 20, 26, 56, 78};

        int result = findMedian(array1, array2);
        print(String.valueOf(result));
    }

    private static void print(String item) {
        System.out.println(item);
    }

}
