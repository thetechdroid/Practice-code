fun main() {

    val array = intArrayOf(1, 2, 3, 5, 6, 7, 8)

    var num1 = array[0]
    var num2 = 1


    





}