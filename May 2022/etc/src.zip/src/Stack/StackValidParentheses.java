package Stack;

import java.util.Stack;

public class StackValidParentheses {

    public static void main(String[] args) {

        String value = "(){}{}[]";
        boolean valid = checkIfValidParentheses(value);
        System.out.println(valid);

    }

    private static boolean checkIfValidParentheses(String value) {
        Stack<Character> stack = new Stack<>();
        for (char c : value.toCharArray()) {
            if (c == '(') {
                stack.push(')');
            } else if (c == '{') {
                stack.push('}');
            } else if (c == '[') {
                stack.push(']');
            } else if (stack.isEmpty() || stack.pop() != c) {
                return false;
            }
        }
        return stack.isEmpty();
    }


}
