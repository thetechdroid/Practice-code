package Stack;

import kotlin.collections.ArraysKt;

import java.util.List;

public class StackImpl {

    int MAX = 100;
    int[] array = new int[MAX];

    public static void main(String[] args) {
        StackWithArray stack = new StackWithArray();

        stack.push(1);
        stack.push(2);
        stack.push(3);
        printStack(stack);

        printPop(stack.pop());
        printStack(stack);
        print(stack.top);

        stack.pop();
        stack.pop();


        printPeek(stack.peek());
        printIfEmpty(stack.isEmpty());


    }

    private static void printStack(StackWithArray stack) {
        for (int i : stack.array) {
            if (i > 0) {
                System.out.print(i + " ");
            }
        }
    }


    private static void print(List<Integer> list) {
        System.out.println("Duplicate items in the list: ");
        for (int i : list) {
            System.out.print(i + " ");
        }
    }

    private static void print(int top) {
        System.out.println("\ntop = " + top);
    }

    private static void printPop(int top) {
        System.out.println("\nPopped element = " + top);
    }

    private static void printPeek(int top) {
        System.out.println("\nPeeked element = " + top);
    }

    private static void printIfEmpty(boolean isEmpty) {
        System.out.println("Stack is empty: " + isEmpty);
    }

}

class StackWithArray {

    int top;
    int MAX = 100;
    int[] array = new int[MAX];

    public StackWithArray() {
        top = 0;
        ArraysKt.fill(array, -1, 0, array.length - 1);
    }


    public void push(int data) {
        if (top > MAX - 1) { // full array
            throw new StackOverflowError("Stack overflow");
        }
        array[top] = data;
        top++;
    }

    public int pop() {
        if (top < 0) { // empty array
            System.out.println("Stack underflow");
            return -1;
        }
        int value = array[top - 1];
        array[top - 1] = -1;
        top--;
        return value;
    }

    public int peek() {
        if (top <= 0) { // empty array
            System.out.println("Stack underflow");
            return -1;
        }
        return array[top-1];
    }

    public boolean isEmpty() {
        return (top == 0 || top == -1);
    }


}
