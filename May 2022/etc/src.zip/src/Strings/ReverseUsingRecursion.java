package Strings;

public class ReverseUsingRecursion {

    public static void main(String[] args) {
        String str = "Hello there!";
        String reverse = reverse(str);
        print(reverse);
    }


    private static String reverse(String str) {
        if (str.isEmpty()) {
            return "";
        }
        return reverse(str.substring(1)) + str.charAt(0);
    }


    private static void print(int[] array) {
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println(" ");
    }

    private static void print(String str) {
        System.out.println(str + " ");
    }


}
