package Strings;

public class Reverse {

    public static void main(String[] args) {
        String str = " Hello how are you doing?";
        char[] reverse = reverseWords(str);
        print(reverse);
    }


    private static char[] reverseWords(String str) {
        if (str.isEmpty()) {
            return new char[]{};
        }

        // assuming the words are separated by a space in between
        char separator = ' ';
        int start = 0;
        char[] array = str.toCharArray();

        for (int i = 0; i < str.length(); i++) {

            if (array[i] == separator || i == str.length() -1) {
                reverse(array, start, i);
                start = i + 1;
            }

        }

        reverse(array, start, array.length -1); // If we are reversing a word in place in the string

        /*reverse(array, 0, array.length -1); // If we are putting words from beginning to end*/

        return array;

    }


    private static void reverse(char[] array, int s, int e) {
        int l = array.length;
        if (l == 0) {
            return;
        }

        int start = s;
        int end = e;
        while (start <= end) {
            char temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }


    private static void print(char[] array) {
        for (char i : array) {
            System.out.print(i);
        }
        System.out.println("");
    }

    private static void print(String str) {
        System.out.println(str + " ");
    }


}
