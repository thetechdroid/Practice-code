package Strings;

public class ReverseAnotherWay {

    public static void main(String[] args) {
        String str = "Clearing DS/Algo round is very hard";
        String reverse = reverseWords(str);
        print(reverse);
    }


    private static String reverseWords(String str) {
        if (str.isEmpty()) {
            return "";
        }

        StringBuilder builder = new StringBuilder();

        String[] array = str.split("\\s");

        for (int i = array.length - 1; i >= 0; i--) {
            builder.append(array[i]).append(" ");
        }

        return builder.toString();

    }


    private static void print(char[] array) {
        for (char i : array) {
            System.out.print(i + " ");
        }
        System.out.println(" ");
    }

    private static void print(String str) {
        System.out.println(str + " ");
    }


}
