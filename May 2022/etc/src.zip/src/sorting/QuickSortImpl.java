package sorting;

public class QuickSortImpl {

    public static void main(String[] args) {
        int[] array = {1, 3, 21, 6, 4, 0, 8, 5, -2};
        quickSort(array, 0, array.length - 1);
        print(array);
    }


    private static void quickSort(int[] array, int start, int end) {
        if (end > start) {
            int par = partition(array, start, end);
            quickSort(array, start, par - 1);
            quickSort(array, par + 1, end);
        }
    }

    private static int partition(int[] array, int start, int end) {
        int pivot = array[end];
        int i = start;

        for (int j = start; j < array.length; j++) {
            if (array[j] < pivot) {
                swap(array, i, j);
                i++;
            }
        }
        swap(array, i, end);
        return i;
    }

    public static void swap(int[] array, int s, int e) {
        int temp = array[s];
        array[s] = array[e];
        array[e] = temp;
    }


    private static void print(int[] array) {
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println("");
    }

    private static void print(String str) {
        System.out.println(str + " ");
    }


}
