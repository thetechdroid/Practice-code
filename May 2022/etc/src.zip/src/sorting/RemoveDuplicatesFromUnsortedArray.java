package sorting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicatesFromUnsortedArray {

    public static void main(String[] args) {
        int[] array = {1, 3, 21, 6, 4, 0, 8, 5, -2, 3, 21, 1};
        //print(array);
        showArrayAfterRemovingDuplicates(array);
    }

    public static void showArrayAfterRemovingDuplicates(int[] array) {
        List<Integer> dupsList = new ArrayList<>();
        Set<Integer> set = new HashSet<>();

        for (int num : array) {
            if (!set.add(num)) {
                dupsList.add(num);
                set.remove(num);
            }else{
                set.add(num);
            }
        }
        print(set);
        print(dupsList);
    }

    private static void print(Set<Integer> list) {
        System.out.println("Unique items in the list: ");
        for (int i : list) {
            System.out.print(i + " ");
        }
        System.out.println("\n");
    }

    private static void print(List<Integer> list) {
        System.out.println("Duplicate items in the list: ");
        for (int i : list) {
            System.out.print(i + " ");
        }
    }

    private static void print(String str) {
        System.out.println(str + " ");
    }


}
