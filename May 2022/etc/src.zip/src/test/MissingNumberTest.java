package test;

import bitwise.MissingNumber;
import org.junit.jupiter.api.Test;

class MissingNumberTest {

    @Test
    public void checkIfFirstNumberMissing() {
        MissingNumber missingNumber = new MissingNumber();
        int[] array = {2, 3, 4, 5, 6, 7};

        int missingNum = missingNumber.getMissingNumber(array);
        assert missingNum == 1;
    }

    @Test
    public void checkIfMiddleNumberMissing() {
        MissingNumber missingNumber = new MissingNumber();
        int[] array = {1, 2, 3, 4, 5, 7};

        int missingNum = missingNumber.getMissingNumber(array);
        assert missingNum == 6;
    }

    @Test
    public void checkIfLastNumberMissing() {
        MissingNumber missingNumber = new MissingNumber();
        int[] array = {1, 2, 3, 4, 5, 6, 7};

        int missingNum = missingNumber.getMissingNumber(array);
        assert missingNum == 8;
    }

}