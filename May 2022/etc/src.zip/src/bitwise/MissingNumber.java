package bitwise;

public class MissingNumber {

    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 6, 7, 8, 9}; // only works if sorted and distinct
        int[] numbersWithout1 = {2, 3, 4, 5, 6, 7, 8, 9};
        int[] numbersWithoutLast = {1, 2, 3, 4, 5, 6, 7, 8, 9};

        MissingNumber number = new MissingNumber();

        int missingNumber = number.getMissingNumber(numbers);
        int missingFirstNumber = number.getMissingNumber(numbersWithout1);
        int missingLastNumber = number.getMissingNumber(numbersWithoutLast);

        print(missingNumber);
        print(missingFirstNumber);
        print(missingLastNumber);
    }


    /**
     * XOR : if you do XOR with self, its always zero
     * if you do XOR with 0, its always self
     *
     * num ^ num = 0
     * num ^ 0 = num
     *
     * */
    public int getMissingNumber(int[] numbers) {
        int result = 0;

        if (numbers[0] != 1) { // this is the base case you need to solve
            return 1;
        }

        for (int i = 1; i < numbers.length; i++) {
            result = result ^ numbers[i];
        }

        for (int i = 2; i <= numbers.length + 1; i++) {
            result = result ^ i;
        }


        return result;


    }


    private static void print(int count) {
        System.out.println("Missing number is : " + count);
    }

    private static void print(String str) {
        System.out.println("The value is " + str);
    }

}
