package bitwise;

public class NumberOf1Bits {

    public static void main(String[] args) {

        int num = 32;

        int count1Bits = getSetBits(num);
        int countTotalBits = getTotalBits(num);
        print(count1Bits);
        printTotal(countTotalBits);
        printZeroBits(countTotalBits - count1Bits);
    }

    private static int getSetBits(int num) {

        int count = 0;
        while (num != 0) {
            num = num & (num - 1);
            count++;
        }
        return count;
    }

    private static int getTotalBits(int num) {

        int count = 0;
        while (num != 0) {
            count++;
            num = num >> 1;
        }
        return count;
    }


    private static void print(int count) {
        System.out.println("Total number of set bits: " + count);
    }

    private static void printTotal(int count) {
        System.out.println("Total number of bits: " + count);
    }

    private static void printZeroBits(int count) {
        System.out.println("Total number of zero bits: " + count);
    }


    private static void print(String str) {
        System.out.println("The value is " + str);
    }

}
