package analyticslogger;

import java.util.List;
import java.util.Map;

public interface AnalyticEvent {

    void sendProperty(String key, String value);

    void sendProperty(String key, int value);

    void sendProperties(Map<String, List<String>> properties); // mention unique USER_ID


    void trackEvent(Event event, Map<String, String> property);

    void trackEvent(Event event, String time, Map<String, String> property);

    void track(Event event, Map<String, List<String>> properties);

    void track(Event event, String time, Map<String, List<String>> properties);

}
