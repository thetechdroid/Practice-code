 How would you approach this problem
 
Steps:

// Back end support, we need an API call/s for sending it over

Questions:

1. Is this associated with a view? or network response?
2. Do we need to send extra properties if its related to view or response?
3. Does these analytics events trigger when user is interacting? or when the app is live or when its in the background?
4. Is it not dependent on events but just trigger periodically at specific time intervals?
5. If it does trigger periodically, what info is it expecting?


Should have thought about functional requirements or non-functional requirements







