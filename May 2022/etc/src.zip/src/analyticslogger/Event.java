package analyticslogger;

public enum Event {

    // sample enum events

    home_screen_launched,
    home_screen_exited,
    home_screen_button_clicked


}
