package analyticslogger;

public class AnalyticsConstants {


    private String USER_ID = "hjklh5687nkl";


    public String getUserId() {
        return USER_ID;
    }


    public void setUserId(String userId) {
        USER_ID = userId;
    }


}
