package analyticslogger;

public class AnalyticsTest {

    public static void main(String[] args) {




        // cliking on a button
        setButtonClickListener();

    }

    private static void setButtonClickListener() {




    }


}
