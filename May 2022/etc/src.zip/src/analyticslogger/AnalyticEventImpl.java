package analyticslogger;

import java.util.List;
import java.util.Map;

public class AnalyticEventImpl implements AnalyticEvent {

    private static AnalyticEventImpl sInstance =  new AnalyticEventImpl(); // will be initialized once

    public static AnalyticEventImpl getInstance(){
        return sInstance;
    }

    @Override
    public void sendProperty(String key, String value) {
        //RestUtil.sendAnalyticsEvent(key, value)
    }

    @Override
    public void sendProperty(String key, int value) {

    }

    @Override
    public void sendProperties(Map<String, List<String>> properties) {



        //RestUtil.sendAnalyticsEvent(AnalyticsConstants.getUserId(). properties)

    }

    @Override
    public void trackEvent(Event event, Map<String, String> property) {

    }

    @Override
    public void trackEvent(Event event, String time, Map<String, String> property) {

    }

    @Override
    public void track(Event event, Map<String, List<String>> properties) {

    }

    @Override
    public void track(Event event, String time, Map<String, List<String>> properties) {

    }


}
