package Arrays;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CountUniqueNumberOfWordsInArray {


    public static void main(String[] args) {
        String[] array = {"Seattle", "Bellevue", "Everett", "Seattle", "Portland", "SFO", "LA", "LA"};
        int count = findUniqueWords(array);
        print(count);
    }


    private static int findUniqueWords(String[] array) {
        Map<String, Integer> map = new HashMap<>();
        int count = 0;
        List<String> results = new ArrayList<>();

        for (String word : array) {
            if (map.containsKey(word)) {
                map.put(word, map.get(word) + 1);
            } else {
                map.put(word, 1);
            }
        }

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if(entry.getValue() == 1){
                results.add(entry.getKey());
                count++;
            }
        }

        print(results);
        return count;
    }


    private static void print(List<String> list) {
        for (String str : list) {
            System.out.print(str + " ");
        }
        System.out.println(" ");
    }

    private static void print(int num) {
        System.out.println("Total unique words are : " + num + " ");
    }


}
