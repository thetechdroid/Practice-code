package Arrays;

public class MaxSubArraySum {


    public static void main(String[] args) {
        int[] array = {-1, 0, 5, 12, 8, -3, -7};
        int maxArraySum = findMaxArraySum(array);
        print(maxArraySum);
    }

    private static int findMaxArraySum(int[] array) {

        int sum = array[0]; // -1
        int maxSum = array[0]; // -1

        for (int i = 1; i < array.length; i++) {
            sum = Math.max(array[i], array[i] + sum);
            maxSum = Math.max(sum, maxSum);
        }
        return maxSum;
    }






    private static void print(int[] array) {
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println(" ");
    }

    private static void print(int num) {
        System.out.println("Max array sum is : " + num + " ");
    }


}
