package Arrays;

import kotlin.collections.ArraysKt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SynonymousSentences { // Wrong solution


    public static void main(String[] args) {
        List<String> pair1 = new ArrayList<>();
        pair1.add("good");
        pair1.add("excellent");

        List<String> pair2 = new ArrayList<>();
        pair2.add("bad");
        pair2.add("sad");

        List<List<String>> pair = new ArrayList<>();
        pair.add(pair1);
        pair.add(pair2);


        List<String> result = generateSentences(pair, "I am having a good day, but yesterday it was a bad day");
        print(result);

    }


    public static List<String> generateSentences(List<List<String>> synonyms, String text) {
        Map<String, String> map = new HashMap<>();

        StringBuilder builder = new StringBuilder();
        String separator = "%";

        //builder.append(text).append(separator);

        for (List<String> synonym : synonyms) { // O(n^n)
            for (int i = 0; i < 2; i++) { // O(n)
                map.put(synonym.get(0), synonym.get(1));
                map.put(synonym.get(1), synonym.get(0));
                if (text.contains(synonym.get(i))) {
                    //int other = i == 0 ? 1 : 0;
                    String tempText = text.replace(synonym.get(i), map.get(synonym.get(i)));
                    builder.append(tempText).append(separator);
                }

                if (text.contains(map.get(synonym.get(i)))) {
                    String tempText = text.replace(synonym.get(i), map.get(synonym.get(i)));
                    builder.append(tempText).append(separator);
                }
            }
        }

        String[] array = builder.toString().split(separator);
        //ArraysKt.sort(array); // O(nlogn)

        return ArraysKt.asList(array);
    }

    private static void print(String[] list) {
        for (String str : list) {
            System.out.print(str + " ");
        }
        System.out.println(" ");
    }

    private static void print(List<String> list) {
        for (String str : list) {
            System.out.println(str + " ");
        }
        System.out.println(" ");
    }


    private static void print(int num) {
        System.out.println("Total unique words are : " + num + " ");
    }


}
