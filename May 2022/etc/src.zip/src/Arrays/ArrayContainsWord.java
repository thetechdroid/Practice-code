package Arrays;

public class ArrayContainsWord {

    public static void main(String[] args) {
        String[] array = {"hello hi", "who is this guys", "how are you?"};
        String word = "hi";
        boolean[] result = checkIfArrayHasTheWord(array, word);

        for(int i = 0; i < array.length; i++){
            print(array[i], result[i]);
        }
    }

    private static boolean[] checkIfArrayHasTheWord(String[] array, String word) {
        boolean[] result = new boolean[array.length];

        // we dont know if item or word would be caps or not, better make all of them small letters
        String wordSmall = word.toLowerCase();

        for (int i = 0; i < array.length; i++) {
            if (array[i].toLowerCase().contains(wordSmall)) {
                result[i] = true;
            }
        }
        return result;
    }


    private static void print(boolean present) {
        System.out.println("The word is present in array: " + present);
    }

    private static void print(String item, boolean present) {
        System.out.println("The word is present in "  + "\"" + item + "\"" +  " -> " + present);
    }


}
