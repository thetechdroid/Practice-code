package Arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CountUniqueNumberOfWordsInArray2 {


    public static void main(String[] args) {
        String[] array = {"Seattle", "Bellevue", "Everett", "Seattle", "Portland", "SFO", "LA", "LA"};

        List<String> list = new ArrayList<>(Arrays.asList(array));
        int count = findUniqueWords(list);
        print(count);
    }


    private static int findUniqueWords(List<String> list) {
        int count = 0;
        List<String> results = new ArrayList<>();

        for (int i = 0; i < list.size(); i++) {
            if (list.indexOf(list.get(i)) == list.lastIndexOf(list.get(i))) {
                count++;
                results.add(list.get(i));
            }
        }
        print(results);
        return count;
    }


    private static void print(List<String> list) {
        for (String str : list) {
            System.out.print(str + " ");
        }
        System.out.println(" ");
    }

    private static void print(int num) {
        System.out.println("Total unique words are : " + num + " ");
    }


}
